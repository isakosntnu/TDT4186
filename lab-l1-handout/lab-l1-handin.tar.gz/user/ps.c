#include "../kernel/types.h"
#include "../user/user.h"

int main(int argc, char const *argv[])
{
   
    ps();
    
    return 0;
}